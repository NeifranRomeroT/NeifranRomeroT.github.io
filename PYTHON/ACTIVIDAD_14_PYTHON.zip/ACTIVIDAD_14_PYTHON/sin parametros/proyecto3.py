#CALCULADORA

#funcion suma
def suma():
    sum=a+b
    print("La suma es: ", sum)

#aplicacion para sumar doe numeros 
a=int(input("Digite el 1er numero: "))
b=int(input("Digite el 2do numero: "))
print("------------------------------")

suma()#llamando a la funcion suma
print("------------------------------")

#funcion resta
def resta():
    res=a-b
    print("La resta es: ", res)

resta()#llamando a la funcion resta
print("------------------------------")


#funcion multiplicacion
def multiplicacion():
    multi=a*b
    print("La multiplicacion es: ", multi)

multiplicacion()#llamando a la funcion multiplicacion
print("------------------------------")



#funcion division
def division():
    divi=a/b
    print("La division es: ", divi)

division()#llamando a la funcion division
print("------------------------------")


