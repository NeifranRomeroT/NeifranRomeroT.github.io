#funcion suma
def suma():
    sum=a+b
    print("La suma es: ", sum)

#aplicacion para sumar doe numeros 
a=int(input("Digite el 1er numero: "))
b=int(input("Digite el 2do numero: "))

suma()#llamando a la funcion suma