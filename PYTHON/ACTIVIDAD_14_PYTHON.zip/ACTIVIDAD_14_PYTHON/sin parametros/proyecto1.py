def dihola():
    print("Hola bienvenido")

dihola() #llamada a la funcion