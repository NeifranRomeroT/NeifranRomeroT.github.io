#App que muestre la multiplicacion de los numeros del 1 al 100
i=1
suma=1
while i<=100:
    i+=1
    suma=suma*i
    print(suma)