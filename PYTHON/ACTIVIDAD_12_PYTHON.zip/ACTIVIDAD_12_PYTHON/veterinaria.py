# veterinaria 

vete={"Spike":{"Nombre":"Spike","Raza":"Labrador","Genero":"M","Dueño":"Julian","Telefono":3008802670,"Color":"Negro","Vacunas":"Si"},"Kira":{"Nombre":"Kira","Raza":"Labrador","Genero":"H","Dueño":"Mayerlis","Telefono":3215294400,"Color":"Blanco","Vacunas":3},"Aaron":{"Nombre":"Aaron","Raza":"Dalmata","Genero":"M","Dueño":"Gustavo","Telefono":3135494565,"Color":"Blanco y Negro","Vacunas":4},"Tobby":{"Nombre":"Tobby","Raza":"Pator Belga","Genero":"M","Dueño":"Neifran","Telefono":3042643027,"Color":"Cafe","Vacunas":"si"},"Lila":{"Nombre":"Lila","Raza":"Pitbull","Genero":"H","Dueño":"Ronaldo","Telefono":3164402539,"Color":"Gris","Vacunas":"si"}}
print(vete["Spike"])
print(vete["Kira"])
print(vete["Aaron"])
print(vete["Tobby"])
print(vete["Lila"])

