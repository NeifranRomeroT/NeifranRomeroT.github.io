"""
Algoritmo que le pregunte el nombre al usuario
"""
nom=input(("Digite su nombre:"))
print("Hola" , nom , "Como estas")
