#Algoritmo que sume 2 numros enteros
a=5
b=7
c=a+b
print("La suma es: ",c)