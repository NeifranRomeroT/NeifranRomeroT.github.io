#Algoritmo que inprima un hola mundo

print("Hola mundo! ")