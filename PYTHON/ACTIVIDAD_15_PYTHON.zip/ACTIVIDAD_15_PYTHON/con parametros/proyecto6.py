#funcion conparametros
#funcion suma

def suma(a,b):
    sum=a+b
    print("La suma es: ", sum)


#app que ingresa 2 enteros y los suma
n=int(input("Digite el 1er numero: "))
m=int(input("Digite el 2do numero: "))

suma(n, m)