#funciones con parametros

#funcion saludo
def saludo(name):
    print("Hola ",name , "Bienvenido")

#app que ingrese el nombre y lo muestre como saludo
nombre=input("Cual es tu nombre ?: ")
saludo(nombre)#llamando a la funcion