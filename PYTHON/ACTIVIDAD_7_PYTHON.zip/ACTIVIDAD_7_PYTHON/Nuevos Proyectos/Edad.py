#App que al ingresar un numero positivo muestre por pantalla todos los años que ha cumplido


x=int(input("Digite un numero: "))


for i in range(1,x+1,2):
    print(i)