# app que pida al usuario una palabra y 
# la muestre 10 veces por pantalla

p=input("escriba una palabra:")

for i in  p*10:
    print (i ,end= " " )
    
    
    