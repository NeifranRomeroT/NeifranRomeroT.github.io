#Escribir lo numeros del 1 al 100 impares
i=3
for i in range(1,100,2):
    print(i)