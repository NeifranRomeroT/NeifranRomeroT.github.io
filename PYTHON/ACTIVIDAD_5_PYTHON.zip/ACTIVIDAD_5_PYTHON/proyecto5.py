#numero pares del 1 al 100

i=2
for i in range(2,100,2):
    print(i)