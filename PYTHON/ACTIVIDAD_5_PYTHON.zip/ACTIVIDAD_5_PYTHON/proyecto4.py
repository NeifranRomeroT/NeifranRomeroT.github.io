#numero del 100 al 1

for i in range(100,1,-1):
    print(i)