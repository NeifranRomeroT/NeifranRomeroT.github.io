#Escribir la multiplicacion del 1 al 100
o=1
for i in range(1,101,1):
    o=o*i
    print(o)