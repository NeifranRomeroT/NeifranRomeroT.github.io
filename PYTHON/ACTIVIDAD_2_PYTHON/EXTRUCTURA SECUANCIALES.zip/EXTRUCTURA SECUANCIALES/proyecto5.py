#Algoritmo que calcule el area del rectangulo
a=int(input("Digite la altura del rectaulo: "))
b=int(input("Digite la base del rectangulo: "))
c=a*b
print("El area del rectangulo es: ",c)
