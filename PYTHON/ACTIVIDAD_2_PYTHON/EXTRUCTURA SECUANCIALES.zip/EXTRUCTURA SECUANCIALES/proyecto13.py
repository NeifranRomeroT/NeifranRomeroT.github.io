#Algoritmo que convierta grados fahrenheit a celcius
a=int(input("Digite los grados fah:"))
celcius=(a-32)*(5/9)
print("La conversion a grados celcius es: ",celcius)